define(
"dijit/form/nls/kk/validate", ({
	invalidMessage: "Енгізілген мән жарамды емес.",
	missingMessage: "Бұл мән міндетті.",
	rangeMessage: "Бұл мән ауқымнан тыс."
})
);
